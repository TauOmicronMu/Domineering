import java.util.HashSet;
import java.util.Set;

public class DomineeringBoard extends Board<DomineeringMove>{
	
	private final boolean[][] b;
	private static final Player H = Player.MAXIMIZER;
	private static final Player V = Player.MINIMIZER;
	
	public DomineeringBoard() {
		b = new boolean[4][4];
		for (boolean[] i : b) {
			for (int j = 0; j < i.length; j++) {
				i[j] = false;
			}
		}
	}
	
	public DomineeringBoard(int m, int n) {
		b = new boolean[m][n];
		for (boolean[] i : b) {
			for (int j = 0; j < i.length; j++) {
				i[j] = false;
			}
		}
	}
	
	private DomineeringBoard(boolean[][] board) {
		b = new boolean[board.length][board[0].length];
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[0].length; j++) {
				b[i][j] = board[i][j];
			}
		}
	}

	@Override
	Player nextPlayer() {
		int total = 0;  
		for (int i = 0; i < b.length; i++) {
			for (int j = 0; j < b[0].length; j++) {
				if (b[i][j]) total++;
			}
		}
		if ((total/2)%2 == 0) {
			return H;
		} 
		else return V;
	}

	@Override
	Set<DomineeringMove> availableMoves() {
		Set<DomineeringMove> s = new HashSet<DomineeringMove>();
		if (nextPlayer().equals(H)) {
			for (int i = 0; i < b.length-1; i++) {
				for (int j = 0; j < b[0].length; j++) {
					if (!b[i][j] && !b[i+1][j]) s.add(new DomineeringMove(i,j,i+1,j));
				}
			}
		}
		else {
			for (int i = 0; i < b.length; i++) {
				for (int j = 0; j < b[0].length-1; j++) {
					if (!b[i][j] && !b[i][j+1]) s.add(new DomineeringMove(i,j,i,j+1));
				}
			}
		}
		return s;
	}

	@Override
	int value() {
		if (availableMoves().isEmpty()) {
			if (nextPlayer().equals(H)) {
				return -1;
			}
			else return 1;
		}
		else return 0;
	}

	@Override
	Board<DomineeringMove> play(DomineeringMove move) {
		boolean[][] board = new boolean[b.length][b[0].length];
		for (int i = 0; i < b.length; i++) {
			for (int j = 0; j < b[0].length; j++) {
				board[i][j] = b[i][j];
			}
		}
		if (!board[move.getMove()[0]][move.getMove()[1]] && 
			!board[move.getMove()[2]][move.getMove()[3]] ) {
			board[move.getMove()[0]][move.getMove()[1]] = true;
			board[move.getMove()[2]][move.getMove()[3]] = true;
		}		
		else {
			System.exit(0);
		}
		return new DomineeringBoard(board);
	}
	
	@Override
	public String toString() {
		String s = "";
		for (int i = 0; i < b.length; i++) {
			for (int j = 0; j < b[0].length; j++) {
				if (b[j][i]) s+= "O";
				else s += "-";
			}
			s+="\n";
		}
		return s;
	}
}
