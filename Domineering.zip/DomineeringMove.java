public class DomineeringMove {
	private final int[] coords;
	
	public DomineeringMove(int x1, int y1, int x2, int y2) {
		coords = new int[4];
		coords[0] = x1;
		coords[1] = y1;
		coords[2] = x2;
		coords[3] = y2;
	}
	
	public int[] getMove() {
		return coords;
	}	
	
	@Override
	public int hashCode() {
		String s = "";
		for (int i = 0; i < coords.length; i++) {
			s += Integer.toBinaryString(coords[i]);
		}
		return Integer.parseInt(s);
	}
	
	@Override
	public boolean equals(Object o) {
		DomineeringMove s = (DomineeringMove) o;
		for (int i = 0; i < coords.length; i++) {
			if (coords[i] != s.getMove()[i]) {
				return false;
			}                                
		}
		return true;
	}
	
	public static DomineeringMove valueOf(String s, Player p) {
		String[] array = s.split(",");
		System.out.flush();
		int a = Integer.parseInt(array[0]);
		int b = Integer.parseInt(array[1]);
		if (p.equals(Player.MAXIMIZER)) {
			return new DomineeringMove(a, b, a+1, b);
		}
		else return new DomineeringMove(a, b, a, b+1);
	}
	
	@Override
	public String toString() {
		String s = "(";
		s += coords[0] + ", " + coords[1] + ")" + " ";
		s += coords[2] + ", " + coords[3] + ")" + " ";
		return s;
	}
}
