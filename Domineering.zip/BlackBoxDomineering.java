import java.util.Scanner;


public class BlackBoxDomineering {
	public static void main(String[] args) {
		assert(args.length == 4);
		int width = Integer.parseInt(args[2]);
		int height = Integer.parseInt(args[3]);
		DomineeringBoard board = new DomineeringBoard(width, height);
		if (args[0].equals("first")) {
			if (args[1].equals("vertical")) {
				board.tree().firstPlayer(new BlackBoxD(Player.MINIMIZER));
			}
			else {
				System.exit(0);
			}
		}
		else {
			if (args[1].equals("horizontal")) {
				board.tree().secondPlayer(new BlackBoxD(Player.MAXIMIZER));
			}
			else {
				System.exit(0);
			}
		}
		
	}
	
	private static class BlackBoxD implements MoveChannel<DomineeringMove> {
		Player player;
		Scanner myScanner;
		public BlackBoxD(Player p) {		
			player = p;
			myScanner = new Scanner(System.in);
		}
		
		public DomineeringMove getMove() {
			return (DomineeringMove.valueOf(myScanner.nextLine(),player));
		}

		public void giveMove(DomineeringMove move) {
			System.err.println("I play " + move);
			System.out.flush();
		}

		public void comment(String msg) {
			System.err.println(msg);
			System.out.flush();
		}

		public void end(int value) {
			System.err.println("Game over. The result is " + value);
			System.out.flush();
		}
	}
}
