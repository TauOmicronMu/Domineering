

public enum Player {
	MAXIMIZER, MINIMIZER;
}
