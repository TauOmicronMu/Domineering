/**
 * Created by tom on 27/03/16.
 */
public class BlackBoxDomineering2 {
}
